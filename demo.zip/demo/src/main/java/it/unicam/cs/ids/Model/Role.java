package it.unicam.cs.ids.Model;

public enum Role {
    CUSTOMER,
    EMPLOYEE,
    SHOP_OWNER,
    UNACCEPTED_SHOP_OWNER,
    ADMINISTRATOR

}
